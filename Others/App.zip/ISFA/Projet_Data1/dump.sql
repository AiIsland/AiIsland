-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : ven. 09 fév. 2024 à 09:13
-- Version du serveur : 10.5.23-MariaDB-cll-lve-log
-- Version de PHP : 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `kwexjgva_ISFA_project1`
--

-- --------------------------------------------------------

--
-- Structure de la table `commercants`
--

CREATE TABLE `commercants` (
  `id` int(11) NOT NULL,
  `type_evenement` enum('mariage','fête','commémoration','anniversaire') NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `prix_gateau_par_personne` decimal(10,2) DEFAULT NULL,
  `prix_decoration_par_m2` decimal(10,2) DEFAULT NULL,
  `prix_musique_par_heure` decimal(10,2) DEFAULT NULL,
  `prix_photographie_par_heure` decimal(10,2) DEFAULT NULL,
  `prix_catering_par_personne` decimal(10,2) DEFAULT NULL,
  `adresse` varchar(255) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `commercants`
--

INSERT INTO `commercants` (`id`, `type_evenement`, `nom`, `description`, `prix_gateau_par_personne`, `prix_decoration_par_m2`, `prix_musique_par_heure`, `prix_photographie_par_heure`, `prix_catering_par_personne`, `adresse`, `telephone`) VALUES
(1, 'mariage', 'Les Noces de Rêve', 'Organisation de mariages de luxe avec une touche personnelle.', 5.50, 15.00, 250.00, 149.00, 70.00, '1 Rue de la Mariée, Saint-Denis', '01 40 01 02 03'),
(2, 'anniversaire', 'Anniversaire Festif', 'Des fêtes d’anniversaire inoubliables pour tous les âges.', 4.00, 12.00, 250.00, 149.00, 70.00, '2 Avenue des Anniversaires, Saint-Denis', '01 40 01 02 04'),
(3, 'commémoration', 'Souvenirs Paisibles', 'Services de commémoration dignes et respectueux.', 6.50, 18.00, 0.00, 149.00, 70.00, '3 Avenue du Souvenir, Saint-Denis', '01 40 01 02 05'),
(4, 'fête', 'Fête Spectaculaire', 'Votre partenaire pour des fêtes mémorables.', 7.00, 20.00, 250.00, 149.00, 70.00, '4 Boulevard des Fêtes, Saint-Denis', '01 40 01 02 06'),
(5, 'mariage', 'Noces de Rêve', 'Votre rêve de mariage réalisé avec perfection.', 8.00, 22.00, 250.00, 149.00, 70.00, '5 Rue des Amoureux, Saint-Denis', '01 40 01 02 07'),
(6, 'anniversaire', 'Année Lumière', 'Des anniversaires magiques pour une journée inoubliable.', 6.50, 16.00, 250.00, 149.00, 70.00, '6 Rue des Étoiles, Saint-Denis', '01 40 01 02 08'),
(7, 'commémoration', 'Mémoire Éternelle', 'Services commémoratifs personnalisés et attentionnés.', 5.50, 14.00, 0.00, 149.00, 70.00, '7 Rue du Souvenir, Saint-Denis', '01 40 01 02 09'),
(8, 'fête', 'La Grande Fête', 'Organisation de fêtes inoubliables et sur mesure.', 7.50, 21.00, 250.00, 149.00, 70.00, '8 Boulevard du Party, Saint-Denis', '01 40 01 02 10'),
(9, 'mariage', 'Gâteaux Enchantés', 'Gâteaux enchantés pour les mariages enchantés.', 6.00, 17.00, 250.00, 149.00, 70.00, '9 Rue de l\'Enchantement, Saint-Denis', '01 40 01 02 11'),
(10, 'anniversaire', 'Sons Festifs', 'Sons festifs pour des anniversaires inoubliables.', 7.00, 19.00, 250.00, 149.00, 70.00, '10 Rue de la Fête, Saint-Denis', '01 40 01 02 12'),
(11, 'commémoration', 'Captures Éternelles', 'Photographes pour des captures éternelles.', 8.50, 23.00, 0.00, 149.00, 70.00, '11 Avenue de l\'Éternité, Saint-Denis', '01 40 01 02 13'),
(12, 'fête', 'Décorations Magiques', 'Décorations enchantées pour des fêtes magiques.', 9.00, 24.00, 250.00, 149.00, 70.00, '12 Avenue de l\'Enchantement, Saint-Denis', '01 40 01 02 14'),
(13, 'mariage', 'Gâteaux de Rêve', 'Créateurs de gâteaux personnalisés pour les mariages.', 5.00, 13.00, 250.00, 149.00, 70.00, '13 Rue du Rêve, Saint-Denis', '01 40 01 02 15'),
(14, 'anniversaire', 'Musique en Folie', 'DJs professionnels pour des anniversaires inoubliables.', 6.00, 15.00, 0.00, 149.00, 70.00, '14 Avenue de la Musique, Saint-Denis', '01 40 01 02 16'),
(15, 'commémoration', 'Instant Capture', 'Services de photographie pour commémorations.', 7.00, 18.00, 0.00, 149.00, 70.00, '15 Boulevard de la Commémoration, Saint-Denis', '01 40 01 02 17'),
(16, 'mariage', 'CommerÃ§ant #1', 'Description du commerÃ§ant #1', 5.00, 24.00, 450.00, 147.00, 60.00, 'Adresse du commerÃ§ant #1', '01 40 21 78'),
(17, 'fête', 'CommerÃ§ant #2', 'Description du commerÃ§ant #2', 2.00, 29.00, 215.00, 340.00, 65.00, 'Adresse du commerÃ§ant #2', '01 40 65 10'),
(18, 'fête', 'CommerÃ§ant #3', 'Description du commerÃ§ant #3', 5.00, 11.00, 168.00, 337.00, 98.00, 'Adresse du commerÃ§ant #3', '01 40 75 28'),
(19, 'anniversaire', 'CommerÃ§ant #4', 'Description du commerÃ§ant #4', 8.00, 27.00, 340.00, 194.00, 74.00, 'Adresse du commerÃ§ant #4', '01 40 78 61'),
(20, 'fête', 'CommerÃ§ant #5', 'Description du commerÃ§ant #5', 8.00, 13.00, 149.00, 168.00, 100.00, 'Adresse du commerÃ§ant #5', '01 40 10 52'),
(21, 'mariage', 'CommerÃ§ant #6', 'Description du commerÃ§ant #6', 7.00, 24.00, 416.00, 461.00, 73.00, 'Adresse du commerÃ§ant #6', '01 40 32 27'),
(22, 'mariage', 'CommerÃ§ant #7', 'Description du commerÃ§ant #7', 8.00, 10.00, 450.00, 494.00, 51.00, 'Adresse du commerÃ§ant #7', '01 40 46 65'),
(23, 'mariage', 'CommerÃ§ant #8', 'Description du commerÃ§ant #8', 4.00, 16.00, 422.00, 283.00, 84.00, 'Adresse du commerÃ§ant #8', '01 40 22 62'),
(24, 'anniversaire', 'CommerÃ§ant #9', 'Description du commerÃ§ant #9', 10.00, 14.00, 104.00, 241.00, 67.00, 'Adresse du commerÃ§ant #9', '01 40 12 85'),
(25, 'mariage', 'CommerÃ§ant #10', 'Description du commerÃ§ant #10', 8.00, 20.00, 430.00, 264.00, 92.00, 'Adresse du commerÃ§ant #10', '01 40 45 29'),
(26, 'mariage', 'Commercant 4577', 'Description du commercant', 29.00, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 'mariage', 'Commercant 3735', 'Description du commercant', 97.00, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 'mariage', 'Commercant 1580', 'Description du commercant', 35.00, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 'mariage', 'Commercant 8624', 'Description du commercant', 40.00, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 'mariage', 'Commercant 7509', 'Description du commercant', 38.00, NULL, NULL, NULL, NULL, NULL, NULL),
(31, 'mariage', 'Commercant 7814', 'Description du commercant', 87.00, NULL, NULL, NULL, NULL, NULL, NULL),
(32, 'mariage', 'Commercant 2035', 'Description du commercant', 69.00, NULL, NULL, NULL, NULL, NULL, NULL),
(33, 'mariage', 'Commercant 1499', 'Description du commercant', 32.00, NULL, NULL, NULL, NULL, NULL, NULL),
(34, 'mariage', 'Commercant 8024', 'Description du commercant', 77.00, NULL, NULL, NULL, NULL, NULL, NULL),
(35, 'mariage', 'Commercant 2063', 'Description du commercant', 53.00, NULL, NULL, NULL, NULL, NULL, NULL),
(36, 'mariage', 'Commercant 8633', 'Description du commercant', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(37, 'mariage', 'Commercant 7583', 'Description du commercant', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(38, 'mariage', 'Commercant 9442', 'Description du commercant', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(39, 'mariage', 'Commercant 8876', 'Description du commercant', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(40, 'mariage', 'Commercant 2366', 'Description du commercant', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(41, 'mariage', 'Commercant 5937', 'Description du commercant', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(42, 'mariage', 'Commercant 1072', 'Description du commercant', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(43, 'mariage', 'Commercant 6973', 'Description du commercant', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(44, 'mariage', 'Commercant 7431', 'Description du commercant', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(45, 'mariage', 'Commercant 2813', 'Description du commercant', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(46, 'anniversaire', 'Commercant 1642', 'Description aléatoire du commercant', 57.30, 99.40, 67.10, 95.87, 59.96, 'Adresse 4', '0794007061'),
(47, 'mariage', 'Commercant 3912', 'Description aléatoire du commercant', 73.91, 95.74, 71.87, 99.70, 26.29, 'Adresse 15', '0418928288'),
(48, 'mariage', 'Commercant 7597', 'Description aléatoire du commercant', 75.72, 25.12, 95.20, 16.83, 60.68, 'Adresse 75', '0801860213'),
(49, 'mariage', 'Commercant 7760', 'Description aléatoire du commercant', 18.35, 38.13, 40.38, 64.58, 72.28, 'Adresse 68', '0940729431'),
(50, 'anniversaire', 'Commercant 1850', 'Description aléatoire du commercant', 31.61, 12.64, 6.25, 12.50, 22.21, 'Adresse 86', '0672335271'),
(51, 'fête', 'Commercant 7889', 'Description aléatoire du commercant', 97.30, 18.62, 77.50, 55.83, 69.45, 'Adresse 59', '0817661952'),
(52, 'fête', 'Commercant 5028', 'Description aléatoire du commercant', 12.24, 84.14, 75.67, 1.41, 81.67, 'Adresse 58', '0712858062'),
(53, 'anniversaire', 'Commercant 4361', 'Description aléatoire du commercant', 25.77, 64.74, 66.20, 95.27, 19.42, 'Adresse 73', '0529705055'),
(54, 'mariage', 'Commercant 4389', 'Description aléatoire du commercant', 92.90, 20.20, 45.38, 55.90, 99.21, 'Adresse 23', '0372099790'),
(55, 'mariage', 'Commercant 8623', 'Description aléatoire du commercant', 18.50, 4.41, 82.10, 85.94, 37.25, 'Adresse 4', '0810293609'),
(56, 'commémoration', 'Commercant 8866', 'Description aléatoire du commercant', 5.44, 51.30, 51.53, 25.17, 87.54, 'Adresse 14', '0279032714'),
(57, 'anniversaire', 'Commercant 9817', 'Description aléatoire du commercant', 99.28, 96.77, 46.27, 32.70, 49.97, 'Adresse 17', '0872383901'),
(58, 'fête', 'Commercant 8470', 'Description aléatoire du commercant', 33.81, 91.22, 35.17, 70.28, 19.13, 'Adresse 22', '0621092328'),
(59, 'anniversaire', 'Commercant 4876', 'Description aléatoire du commercant', 34.64, 56.41, 19.58, 21.45, 32.00, 'Adresse 61', '0861222787'),
(60, 'commémoration', 'Commercant 4284', 'Description aléatoire du commercant', 1.88, 13.70, 63.86, 6.65, 99.53, 'Adresse 57', '0301335157'),
(61, 'anniversaire', 'Commercant 6592', 'Description aléatoire du commercant', 60.11, 70.55, 32.99, 91.10, 86.50, 'Adresse 51', '0224798588'),
(62, 'commémoration', 'Commercant 5384', 'Description aléatoire du commercant', 37.90, 68.54, 11.41, 80.20, 41.36, 'Adresse 51', '0853854734'),
(63, 'fête', 'Commercant 8785', 'Description aléatoire du commercant', 37.55, 96.79, 84.67, 94.51, 82.38, 'Adresse 81', '0705116035'),
(64, 'commémoration', 'Commercant 8701', 'Description aléatoire du commercant', 13.47, 58.90, 15.42, 58.39, 60.56, 'Adresse 83', '0722536060'),
(65, 'mariage', 'Commercant 7680', 'Description aléatoire du commercant', 71.57, 78.10, 46.54, 50.79, 61.27, 'Adresse 9', '0995004794'),
(66, 'commémoration', 'Commercant 5965', 'Description aléatoire du commercant', 72.65, 78.23, 72.76, 75.61, 2.70, 'Adresse 91', '0366938194'),
(67, 'fête', 'Commercant 8250', 'Description aléatoire du commercant', 21.49, 35.30, 42.62, 71.98, 44.66, 'Adresse 42', '0542247508'),
(68, 'anniversaire', 'Commercant 8970', 'Description aléatoire du commercant', 81.42, 75.42, 11.48, 8.89, 53.86, 'Adresse 76', '0620219683'),
(69, 'anniversaire', 'Commercant 6367', 'Description aléatoire du commercant', 64.34, 44.61, 32.94, 46.96, 16.71, 'Adresse 58', '0221775146'),
(70, 'mariage', 'Commercant 1719', 'Description aléatoire du commercant', 56.86, 83.90, 88.10, 100.62, 70.98, 'Adresse 88', '0533259631'),
(71, 'mariage', 'Commercant 1822', 'Description aléatoire du commercant', 67.88, 21.40, 45.96, 38.70, 30.15, 'Adresse 51', '0805537691'),
(72, 'commémoration', 'Commercant 1145', 'Description aléatoire du commercant', 73.79, 81.39, 21.81, 32.82, 54.56, 'Adresse 40', '0807168791'),
(73, 'fête', 'Commercant 4452', 'Description aléatoire du commercant', 22.50, 35.89, 47.53, 30.71, 68.80, 'Adresse 2', '0740714192'),
(74, 'mariage', 'Commercant 9075', 'Description aléatoire du commercant', 14.92, 32.96, 30.28, 40.38, 97.34, 'Adresse 86', '0482360785'),
(75, 'mariage', 'Commercant 7488', 'Description aléatoire du commercant', 43.47, 78.84, 30.45, 12.40, 49.71, 'Adresse 46', '0381734320');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `commercants`
--
ALTER TABLE `commercants`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `commercants`
--
ALTER TABLE `commercants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
