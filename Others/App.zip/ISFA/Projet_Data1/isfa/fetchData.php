<?php
require_once('_init.php');


$query = "SELECT * FROM commercants";
$result = $mysqli->query($query);

if (!$result) {
    die("Error in SQL query: " . $mysqli->error);
}

$commercants = [];

while ($row = $result->fetch_assoc()) {
    array_walk_recursive($row, function(&$item) {
        $item = utf8_encode($item);
    });
    $commercants[] = $row;
}

$mysqli->close();

echo json_encode($commercants);
?>
