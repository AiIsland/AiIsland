<?php

require_once('_init.php');

$successMessage = "";
$errorMessage = "";

if(isset($_POST['submit'])) {
    $num_commercants = $_POST['num_commercants'];

    for($i = 0; $i < $num_commercants; $i++) {
        $commercant = generateRandomCommercant();

        $query = "INSERT INTO `commercants` (`type_evenement`, `nom`, `description`, `prix_gateau_par_personne`, `prix_decoration_par_m2`, `prix_musique_par_heure`, `prix_photographie_par_heure`, `prix_catering_par_personne`, `adresse`, `telephone`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        if ($stmt = $mysqli->prepare($query)) {
            $stmt->bind_param("ssssssssss", $commercant['type_evenement'], $commercant['nom'], $commercant['description'], $commercant['prix_gateau_par_personne'], $commercant['prix_decoration_par_m2'], $commercant['prix_musique_par_heure'], $commercant['prix_photographie_par_heure'], $commercant['prix_catering_par_personne'], $commercant['adresse'], $commercant['telephone']);
            if (!$stmt->execute()) {
                $errorMessage = "Erreur lors de l'ajout des commerçants.";
            }
            $stmt->close();
        } else {
            $errorMessage = "Erreur lors de la préparation de la requête.";
        }
    }

    if (empty($errorMessage)) {
        $successMessage = "$num_commercants commerçant(s) ajouté(s) avec succès.";
    }
}

function generateRandomCommercant() {
    $typesEvenement = ['mariage', 'fête', 'commémoration', 'anniversaire'];
    $typeEvenement = $typesEvenement[array_rand($typesEvenement)];
    $nom = "Commerçant " . rand(1000, 9999);
    $description = "Description aléatoire du commerçant";
    $prixGateau = rand(1, 100) . '.' . rand(0, 99);
    $prixDecoration = rand(1, 100) . '.' . rand(0, 99);
    $prixMusique = rand(1, 100) . '.' . rand(0, 99);
    $prixPhotographie = rand(1, 100) . '.' . rand(0, 99);
    $prixCatering = rand(1, 100) . '.' . rand(0, 99);
    $adresse = "Adresse " . rand(1, 100);
    $telephone = "0" . rand(100000000, 999999999);

    return [
        'type_evenement' => $typeEvenement,
        'nom' => $nom,
        'description' => $description,
        'prix_gateau_par_personne' => $prixGateau,
        'prix_decoration_par_m2' => $prixDecoration,
        'prix_musique_par_heure' => $prixMusique,
        'prix_photographie_par_heure' => $prixPhotographie,
        'prix_catering_par_personne' => $prixCatering,
        'adresse' => $adresse,
        'telephone' => $telephone
    ];
}

// Importation depuis un fichier CSV
if(isset($_POST['import_csv'])) {
    $file = $_FILES['file']['tmp_name'];
    $handle = fopen($file, "r");
    $header = true; // Indicateur pour ignorer la première ligne du fichier
    while(($row = fgetcsv($handle, 1000, ",")) !== false) {
        if($header) {
            $header = false; // Passer à la prochaine ligne après avoir lu l'en-tête
            continue;
        }
        $type_evenement = $row[0];
        $nom = $row[1];
        $description = $row[2];
        $prix_gateau_par_personne = $row[3];
        $prix_decoration_par_m2 = $row[4];
        $prix_musique_par_heure = $row[5];
        $prix_photographie_par_heure = $row[6];
        $prix_catering_par_personne = $row[7];
        $adresse = $row[8];
        $telephone = $row[9];

        $query = "INSERT INTO `commercants` (`type_evenement`, `nom`, `description`, `prix_gateau_par_personne`, `prix_decoration_par_m2`, `prix_musique_par_heure`, `prix_photographie_par_heure`, `prix_catering_par_personne`, `adresse`, `telephone`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        if ($stmt = $mysqli->prepare($query)) {
            $stmt->bind_param("ssssssssss", $type_evenement, $nom, $description, $prix_gateau_par_personne, $prix_decoration_par_m2, $prix_musique_par_heure, $prix_photographie_par_heure, $prix_catering_par_personne, $adresse, $telephone);
            $stmt->execute();
            $stmt->close();
        } else {
            $errorMessage = "Erreur lors de la préparation de la requête.";
        }
    }
    fclose($handle);
    $successMessage = "Importation réussie depuis le fichier CSV.";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajout de Commerçants</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .message {
            margin: 20px 0;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        input[type="number"], input[type="submit"], input[type="file"] {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin: 5px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Ajout de Commerçants</h1>

        <?php if (!empty($successMessage)): ?>
            <div class="message">
                <?php echo $successMessage; ?>
            </div>
        <?php endif; ?>
        <?php if (!empty($errorMessage)): ?>
            <div class="message" style="background-color: #dc3545; color: white;">
                <?php echo $errorMessage; ?>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <label for="file">Importer depuis un fichier CSV :</label>
            <input type="file" name="file" id="file" accept=".csv">
            <input type="submit" name="import_csv" value="Importer">
            <a href="modele.csv" download>Télécharger le modèle CSV</a>
        </form>

        <form method="POST">
            <label for="num_commercants">Nombre de commerçants à ajouter :</label>
            <input type="number" id="num_commercants" name="num_commercants" min="1" required>
            <input type="submit" name="submit" value="Ajouter Commerçants">
        </form>

        <?php
        // Affichage des commerçants ajoutés
        $query = "SELECT nom, type_evenement, description FROM commercants ORDER BY id DESC LIMIT 10";
        $result = $mysqli->query($query);

        if ($result->num_rows > 0) {
            echo "<h2>Commerçants récemment ajoutés :</h2>";
            echo "<table>";
            echo "<tr><th>Nom</th><th>Type d'événement</th><th>Description</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>".$row["nom"]."</td><td>".$row["type_evenement"]."</td><td>".$row["description"]."</td></tr>";
            }
            echo "</table>";
        } else {
            echo "<p>Aucun commerçant ajouté.</p>";
        }
        ?>

    </div>
</body>
</html>
