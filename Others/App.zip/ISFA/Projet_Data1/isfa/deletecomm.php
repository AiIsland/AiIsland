<?php
require_once('_init.php');


$successMessage = "";
$errorMessage = "";

// Suppression d'un commerçant sélectionné
if(isset($_POST['deleteSelected'])) {
    $selectedId = $_POST['selectedId'];
    $query = "DELETE FROM `commercants` WHERE id = ?";
    if ($stmt = $mysqli->prepare($query)) {
        $stmt->bind_param("i", $selectedId);
        if (!$stmt->execute()) {
            $errorMessage = "Erreur lors de la suppression du commerçant.";
        } else {
            $successMessage = "Commerçant supprimé avec succès.";
        }
        $stmt->close();
    } else {
        $errorMessage = "Erreur lors de la préparation de la requête.";
    }
}

// Suppression d'un nombre spécifié de commerçants
if(isset($_POST['submit'])) {
    $num_commercants = $_POST['num_commercants'];

    $query = "DELETE FROM `commercants` ORDER BY id DESC LIMIT ?";
    if ($stmt = $mysqli->prepare($query)) {
        $stmt->bind_param("i", $num_commercants);
        if (!$stmt->execute()) {
            $errorMessage = "Erreur lors de la suppression des commerçants.";
        } else {
            $successMessage = "$num_commercants commerçant(s) supprimé(s) avec succès.";
        }
        $stmt->close();
    } else {
        $errorMessage = "Erreur lors de la préparation de la requête.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Suppression de Commerçants</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .message {
            margin: 20px 0;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        input[type="number"], input[type="submit"] {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin: 5px;
        }
        input[type="submit"] {
            background-color: #dc3545;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Suppression de Commerçants</h1>

        <?php if (!empty($successMessage)): ?>
            <div class="message" style="background-color: #28a745; color: white;">
                <?php echo $successMessage; ?>
            </div>
        <?php endif; ?>
        <?php if (!empty($errorMessage)): ?>
            <div class="message" style="background-color: #dc3545; color: white;">
                <?php echo $errorMessage; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <label for="num_commercants">Nombre de commerçants à supprimer :</label>
            <input type="number" id="num_commercants" name="num_commercants" min="1" required>
            <input type="submit" name="submit" value="Supprimer Commerçants">
        </form>

        <h2>Supprimer un commerçant spécifique :</h2>
        <form method="POST">
            <label for="selectedId">Sélectionnez l'ID du commerçant à supprimer :</label>
            <input type="number" id="selectedId" name="selectedId" min="1" required>
            <input type="submit" name="deleteSelected" value="Supprimer Commerçant">
        </form>

        <?php
        // Affichage des commerçants restants
        $query = "SELECT id, nom, type_evenement, description FROM commercants";
        $result = $mysqli->query($query);

        if ($result->num_rows > 0) {
            echo "<h2>Commerçants Restants :</h2>";
            echo "<table>";
            echo "<tr><th>ID</th><th>Nom</th><th>Type d'événement</th><th>Description</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>".$row["id"]."</td><td>".$row["nom"]."</td><td>".$row["type_evenement"]."</td><td>".$row["description"]."</td></tr>";
            }
            echo "</table>";
        } else {
            echo "<p>Aucun commerçant restant.</p>";
        }
        ?>

    </div>
</body>
</html>
