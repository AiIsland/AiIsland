<?php
// Connexion à la base de données
$host = "db"; // Modifié de "localhost" à "db"
$username = "root";
$password = "rootpassword";
$database = "ISFAdb_1";
$mysqli = new mysqli($host, $username, $password, $database);
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
$mysqli->set_charset("utf8");
?>

