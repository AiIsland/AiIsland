<?php
require_once('_init.php');

// Vérifier si l'ID est fourni
if (isset($_POST['id']) && is_numeric($_POST['id'])) {
    $id = $_POST['id'];

    // Préparer la requête SQL pour récupérer les informations du commerçant
    $query = "SELECT * FROM commercants WHERE id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("i", $id);

    // Exécuter la requête
    $stmt->execute();
    $result = $stmt->get_result();

    // Vérifier si un commerçant a été trouvé
    if ($row = $result->fetch_assoc()) {
        echo json_encode($row);
    } else {
        echo "Aucun commerçant trouvé avec l'ID: " . $id;
    }

    // Fermer la requête préparée
    $stmt->close();
} else {
    echo "ID de commerçant non fourni ou invalide.";
}

// Fermer la connexion
$mysqli->close();
?>
