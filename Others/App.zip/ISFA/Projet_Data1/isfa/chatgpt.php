<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["question"])) {
    $question = $_POST["question"];

    $url = 'https://api.openai.com/v1/chat/completions';
    $data = [
        'model' => 'gpt-3.5-turbo-1106',
        'messages' => [['role' => 'user', 'content' => $question]],
        'max_tokens' => 50
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer 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' 
    ]);

    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        echo 'Erreur cURL : ' . curl_error($ch);
    }

    curl_close($ch);

    if ($response) {
        $decodedResponse = json_decode($response, true);
        if (isset($decodedResponse['choices'][0]['message']['content'])) {
            echo $decodedResponse['choices'][0]['message']['content'];
        } else {
            echo "Réponse reçue mais pas de texte : " . $response;
        }
    } else {
        echo "Aucune réponse reçue de l'API.";
    }
}
?>
