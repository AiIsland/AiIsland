<?php
ob_start(); 
require_once('_init.php');

// Nom du fichier CSV à télécharger
$filename = "liste_commercants.csv";

// En-têtes pour forcer le téléchargement
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . $filename . '"');

// Ouvrir le fichier en écriture
$file = fopen('php://output', 'w');

// Écrire l'en-tête du fichier CSV
fputcsv($file, array('ID', 'Nom', 'Type d\'événement', 'Description', 'Prix gâteau', 'Prix décoration', 'Prix musique', 'Prix photographie', 'Prix catering', 'Adresse', 'Téléphone'));

// Sélectionner tous les commercants depuis la base de données
$query = "SELECT * FROM commercants";
$result = $mysqli->query($query);

// Écrire chaque commercant dans le fichier CSV
while ($row = $result->fetch_assoc()) {
    fputcsv($file, $row);
}

// Fermer le fichier
fclose($file);

// Fermer la connexion à la base de données
$mysqli->close();

// Afficher un message de téléchargement réussi
echo "Téléchargement réussi !";
ob_end_flush(); 
?>
