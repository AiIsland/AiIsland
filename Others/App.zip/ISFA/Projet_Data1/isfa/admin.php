<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajout et Suppression de Commerçants</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .message {
            margin: 20px 0;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
        }
        input[type="submit"], input[type="button"] {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
            margin: 5px;
        }
        input[type="submit"]:hover, input[type="button"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Ajouter et Supprimer des Commerçants</h1>

        <?php if (!empty($successMessage)): ?>
            <div class="message">
                <?php echo $successMessage; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <input type="button" onclick="window.location.href='addcomm.php';" value="Ajouter Commerçant">
            <input type="button" onclick="window.location.href='deletecomm.php';" value="Supprimer Commerçant" style="background-color: #dc3545;">
            <input type="button" onclick="window.location.href='down_comm.php';" value="Téléchargement de la liste des commerçants">
        </form>
    </div>
</body>
</html>
