<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Compagnon Événementiel : Votre Expert en Événements grâce à l'IA</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Helvetica Neue', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        h1 {
            font-size: 36px;
            color: #333;
            margin-bottom: 20px;
        }

        #adminButtonContainer {
            text-align: left;
            margin-left: 20px;
        }

        #adminButton {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 12px 20px;
            cursor: pointer;
            font-size: 18px;
        }

        #chatForm {
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 10px;
        }

        select,
        input[type="number"] {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 12px 20px;
            cursor: pointer;
            font-size: 18px;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        #response {
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: left;
            margin-top: 20px;
            font-size: 18px;
        }

        #timer {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div id="adminButtonContainer">
        <a href="login.php" id="adminButton">Admin</a>
    </div>
    <h1>Compagnon Événementiel</h1>
    <form id="chatForm">
        <label for="typeEvenement">Type d'événement:</label>
        <select id="typeEvenement" name="typeEvenement">
            <option value="mariage">Mariage</option>
            <option value="fête">Fête</option>
            <option value="commémoration">Commémoration</option>
            <option value="anniversaire">Anniversaire</option>
        </select>
        <br><br>
        <label for="minNombrePersonnes">Nombre de personnes (min):</label>
        <input type="number" id="minNombrePersonnes" name="minNombrePersonnes">
        <br><br>
        <label for="maxNombrePersonnes">Nombre de personnes (max):</label>
        <input type="number" id="maxNombrePersonnes" name="maxNombrePersonnes">
        <br><br>
        <label for="minSurfaceEvenement">Surface de l'événement (min en m²):</label>
        <input type="number" id="minSurfaceEvenement" name="minSurfaceEvenement">
        <br><br>
        <label for="maxSurfaceEvenement">Surface de l'événement (max en m²):</label>
        <input type="number" id="maxSurfaceEvenement" name="maxSurfaceEvenement">
        <br><br>
        <input type="submit" value="Envoyer">
    </form>
    <div id="response"></div>
    <div id="timer"></div>

    <script>
        $(document).ready(function() {
            $('#chatForm').on('submit', function(e) {
                e.preventDefault();
                var startTime = performance.now();

                var typeEvenement = $('#typeEvenement').val();
                var minNombrePersonnes = $('#minNombrePersonnes').val();
                var maxNombrePersonnes = $('#maxNombrePersonnes').val();
                var minSurfaceEvenement = $('#minSurfaceEvenement').val();
                var maxSurfaceEvenement = $('#maxSurfaceEvenement').val();

                $.ajax({
                    url: 'fetchData.php',
                    type: 'GET',
                    data: {
                        typeEvenement: typeEvenement,
                        minNombrePersonnes: minNombrePersonnes,
                        maxNombrePersonnes: maxNombrePersonnes,
                        minSurfaceEvenement: minSurfaceEvenement,
                        maxSurfaceEvenement: maxSurfaceEvenement
                    },
                    success: function(data) {
                        var commercants = JSON.parse(data);
                        var question = "Identifiez le commerçant le plus adapté pour un(e) " + typeEvenement + 
                        " avec entre " + minNombrePersonnes + " et " + maxNombrePersonnes + 
                        " personnes, et une surface de " + minSurfaceEvenement + 
                        " à " + maxSurfaceEvenement + " m², parmi ces options : " + 
                        JSON.stringify(commercants) + ". Merci de répondre sous la forme , ne dis rien directement donne moi respecte les virgule ta reponse doit avoir les virgules : Nom, adresse, téléphone, coût total estimé.";

                        $.ajax({
                            url: 'chatgpt.php',
                            type: 'POST',
                            data: { question: question },
                            success: function(response) {
                                var endTime = performance.now();
                                var timeTaken = (endTime - startTime) / 1000; // Convert milliseconds to seconds
                                var result = response.split(",");
                                var formattedResponse = "Nom : " + result[0] + "<br>" +
                                                "Adresse : " + result[1] + "<br>" +
                                                "Téléphone : " + result[3] + "<br>" +
                                                "Coût total : " + result[4];
                                $('#response').html("Commerçant recommandé:<br>" + formattedResponse);
                                $('#timer').html("Temps de réponse: " + timeTaken.toFixed(2) + " secondes.");
                            }
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>

